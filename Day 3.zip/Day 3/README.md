
feels_like: 24.61
grnd_level: 943
humidity: 87
pressure: 1005
sea_level: 1005
temp: 23.07
temp_max: 23.07
temp_min: 23.07

  a.innerHTML = cityname + " City Temperature" + " " + "<br>"+"<br>"+

         "Feels-Like = " +feels + "<br>"+"<br>"+

         "Ground-Level = " +ground + "<br>"+"<br>"+

         "Humidity = " + humidity + "<br>"+"<br>"+

         "Sea-Level = " + sea+ "<br>"+"<br>"+

         "Pressure = " + pressure + "<br>"+"<br>"+

         "Max-Temperature = " + max + "<br>"+"<br>"+

         "Min-Temperature = " + min + "<br>"+"<br>";
    

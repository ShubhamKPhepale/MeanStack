
   var cityname;

  let logic1 = function()
  {
      let req = new XMLHttpRequest();

      var read = document.querySelector("#inputid").value;

       cityname = read;

      let url = "https://api.openweathermap.org/data/2.5/weather?appid=d1ed5fdcfd331066dc0252d0e78b4d8f&units=metric&q=";

      url = url  + cityname;

      req.open('GET',url);

    /*req.onreadystatechange = () =>
    {
      if (this.readyState == 4 && this.status == 200) 
      {
         console.log(req.responseText);
        const refjson = JSON.parse(req.responseText);
      }
    };*/

      req.onload = () =>
      {
          console.log(req.responseText);

          const refjson = JSON.parse(req.responseText);

            
        
          operation(refjson);
      }

      req.send();
  };




let operation =  function(refjson)
  {

      console.log(refjson);

      var min = refjson.main.temp_min;

      const max = refjson.main.temp_max;

      const feels = refjson.main.feels_like;

      const ground = refjson.main.grnd_level;

      const humidity = refjson.main.humidity;

      const pressure = refjson.main.pressure;

      const sea = refjson.main.sea_level;

      const temp = refjson.main.temp;


      const a = document.querySelector("#content")

       const feel1 = document.querySelector("#pin1").value = feels;

       const ground1 = document.querySelector("#pin2").value = ground;

       const hum1 = document.querySelector("#pin3").value = humidity;

       const sea1 = document.querySelector("#pin4").value = sea;

       const pre1 = document.querySelector("#pin5").value = pressure;

       const max1 = document.querySelector("#pin6").value =  max ;

       const min1 = document.querySelector("#pin7").value = min ;

      
        document.querySelector("#inputid").value = " ";

        

  }
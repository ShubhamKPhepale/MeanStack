const http = require('http');

http.createServer((request,response) =>
{
   // response.end("hello");

    let jsonref = 
    {
        add : 'loni',

        name :'samrat'
    }

      response.end(JSON.stringify(jsonref));


}).listen(5500);
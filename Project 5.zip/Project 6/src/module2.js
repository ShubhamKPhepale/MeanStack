const promise  = require("bluebird");

 const mysql = require("mysql");
//const { try } = require("bluebird");

 promise.promisifyAll(require("mysql/lib/Connection").prototype);

 promise.promisifyAll(require("mysql/lib/Pool").prototype);

  let DB_CONFIG = 
  {
      host : "localhost",
      user : "root",
      password : "root",
      database : "DAC20"
  }

  var records = [
    [7, 'Yashwant', 'Chavan@3'],
    [8, 'Diwakar', 'Patil@2'],
    [9, 'Anoop', 'More@1']
];



   let insert1 = async() =>
   {

      const conn = mysql.createConnection(DB_CONFIG);

      conn.connectAsync();

      let sql = "insert into user values ?";

      let opertion  = await conn.queryAsync(sql,[records],function(err,data)
      {

        console.log(data);
});
           await conn.endAsync();

           return opertion;
   };

     if(insert1())
     {
         console.log("Data has been inserted");
     }
     else
     {
         console.log("Something bad has happend");
     }

       //insert1();

 const promise  = require("bluebird");

 const mysql = require("mysql");

 promise.promisifyAll(require("mysql/lib/Connection").prototype);

 promise.promisifyAll(require("mysql/lib/Pool").prototype);

  let DB_CONFIG = 
  {
      host : "localhost",
      user : "root",
      password : "root",
      database : "DAC20"
  }

 
   let read = async() =>
   {

      const conn = mysql.createConnection(DB_CONFIG); // connection to database

        conn.connectAsync();

        let sql = "select * from user";

        let result = await conn.queryAsync(sql);

        console.log(result);

        conn.endAsync();

        return result;


   }


     read();

     
const mysql = require("mysql");

const promise = require("bluebird");

const DB = require("./dbconfig");

promise.promisifyAll(require("mysql/lib/Connection").prototype);
promise.promisifyAll(require("mysql/lib/Pool").prototype);

var data1 = [
    [12,"titu","n@gmail.com"],
    [13,"burman","n@gmail.com"]
];

let insert = async() =>
{
    const conn = mysql.createConnection(DB.DB_CONFIG);

      await conn.connectAsync();

      let sql = "insert into user values ? "

      const result =  await conn.queryAsync(sql,[data1],function(err,data)
       {
             console.log(data);
       });

         await conn.endAsync();

        return result;
};

 // insert();

 module.exports = 
 {
     insert
 }
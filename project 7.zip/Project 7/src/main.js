
 const dbread = require("./read");

 const dsearch = require("./searchby");

 const insert1 = require("./insert");

 console.log(dbread.read());

 console.log(dsearch.serachby());

 console.log(insert1.insert());

const mysql = require("mysql");

const promise = require("bluebird");

const DB = require("./dbconfig");

promise.promisifyAll(require("mysql/lib/Connection").prototype);
promise.promisifyAll(require("mysql/lib/Pool").prototype);


let serachby = async () =>
{
      const connection  = mysql.createConnection(DB.DB_CONFIG);

       connection.connectAsync();

      let sql = "select * from user where name = ?";

      let result = await connection.queryAsync(sql,["samrat"]);

      console.log(result);
      
      await connection.endAsync();

      return result;
};

  //serachby();

  module.exports = 
  {
      serachby
  }
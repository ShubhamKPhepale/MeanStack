
 const mysql = require("mysql");

 const promise = require("bluebird");

 const DB = require("./dbconfig");

 promise.promisifyAll(require("mysql/lib/Connection").prototype);
 promise.promisifyAll(require("mysql/lib/Pool").prototype);

 let read = async(err,data) =>

 {
    const connection  = mysql.createConnection(DB.DB_CONFIG);

     connection.connectAsync();

    let sql = "select * from user";

    let result  = await connection.queryAsync(sql);

    console.log(result);

    connection.endAsync();

    return result;

 };

   read();

   module.exports = 
   {
       read
   }



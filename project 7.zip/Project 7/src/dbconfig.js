
const DB_CONFIG = 
{
    host : "localhost",
    user : "root",
    password : "root",
    database : "DAC20"
}

module.exports = 
{
    DB_CONFIG
}
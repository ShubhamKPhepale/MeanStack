
 
 const list = [

    {id:1,Name:"samrat",address:"loni",pincode:413711},

    {id:2,Name:"sandy",address:"utur",pincode:413712},

    {id:3,Name:"rahul",address:"satara",pincode:413713},

    {id:4,Name:"akshay",address:"satara",pincode:413714},

    {id:5,Name:"shubham",address:"koperagon",pincode:413715},

    {id:6,Name:"Tejas",address:"nagar",pincode:413716},

    {id:7,Name:"suraj",address:"nashik",pincode:413717},

    {id:8,Name:"mahesh",address:"nashik",pincode:413718},

    {id:9,Name:"rajesh",address:"nanded",pincode:413719},

    {id:10,Name:"akash",address:"malegaon",pincode:413720},

 ];

 module.exports = 
 {
     list
 };
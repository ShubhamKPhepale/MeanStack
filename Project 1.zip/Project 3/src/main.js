
const http = require("http")

 const mod = require("./module");

 http.createServer((req,res)=>
 {
     res.setHeader("Access-Control-Allow-Origin","*");

    const myres = JSON.stringify(mod.list);

      res.end(myres);

 }).listen(5100);

 //console.log(mod);

 //console.log(mod.list);

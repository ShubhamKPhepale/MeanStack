
 let operation = function()
 {

    let req = new XMLHttpRequest();

    const url = "http://localhost:5100/";

     req.open('GET',url);

     req.onload = () =>
     {
         const data = JSON.parse(req.responseText);

         console.log(data);

         logic1(data);

     };

     req.send();


 };

   let logic1 = function(data)
   {
         let read = document.querySelector("#mainid");

          for(let  i = 0 ; i<data.length ; i++)
          {

            let items = data[i];

            const element = read.children[0].cloneNode(true);

            element.style.display = "flex";
        
             element.innerHTML = items.id +" "+items.Name+" "+items.address+" "+items.pincode; 

             read.insertBefore(element,read.firstChild);

          }
         
   };

 window.addEventListener("load", function()
 {
    let req = new XMLHttpRequest();

    const url = 'https://reqres.in/api/users?page=2';

    req.open("GET",url);    

    req.onreadystatechange = () => 
    
    {
        if (req.readyState == 4)
        
        {

          let sjson = JSON.parse(req.responseText);

            logic1(sjson.data);
          
        }
      };

      req.send();

    });

      var count = 0;

       let logic1 = function(list)
      {

          for(let i = 0 ; i<list.length ; i++)
          {
              let items = list[i];
   
      const read = document.querySelector("#BlockContainer");

      var clonediv = read.children[0].cloneNode(true);

      clonediv.style.display = "flex";

      count = count + 1 ;

      clonediv.children[0].innerHTML = items.last_name + " " + count;

      read.insertBefore(clonediv,read.firstChild);
          }

      }

 

  window.addEventListener("load", () => 
  {

    var emp = [{id:1,name:"samrat"},

               {id:2,name:"sandy"},

               {id:3,name:"akshay"},

               {id:4,name:"shubham"},

               {id:5,name:"rahul"}

    ];
    
    for(let i = 0  ; emp.length ; i++)
    {

          let items = emp[i];

     const read = document.querySelector("#block1");

     var clonediv = read.children[0].cloneNode(true);

     clonediv.style.display = "flex";

     clonediv.children[0].innerHTML = items.id + " " + items.name;

      //document.body.appendChild(clonediv);

     read.insertBefore(clonediv,read.firstChild);


    }

  });
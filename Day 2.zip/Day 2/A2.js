
 let logic1 = function()
{
    let xhr = new XMLHttpRequest();

    const url = 'https://reqres.in/api/users?page=2';

    xhr.open("GET", url);

    xhr.onreadystatechange = () => 
    
    {
        if (xhr.readyState == 4)
        
        {
        const refJson = JSON.parse(xhr.responseText);
       
        domLogic(refJson.data);
        }
      };
    
     

      xhr.send();
    };
    

    let domLogic = function (refJson)
     {

        var reads  = document.querySelector("#parentid");
    
        for (let i = 0; i < refJson.length; i++) 
        {

              const items = refJson[i];

              let element1 = reads.children[0].cloneNode(true);

               element1.style.display = "flex";

              element1.innerHTML = items.first_name + " " + items.last_name;

              reads.insertBefore(element1,reads.firstChild);


}

     };
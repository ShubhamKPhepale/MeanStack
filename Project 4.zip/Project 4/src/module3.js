const promise = require("bluebird");

const fs = require("fs");

promise.promisifyAll(fs); // makes all the file methods sequential

let readDemo = () => {
    const filePath1 = "C:/Users/hp/Dropbox/Interview Questions/JavaScript/Day 2.txt";
  
    // Promise
    const mpromise = fs.readFileAsync(filePath1, { encoding: "utf-8" });
    console.log(mpromise);
  
    // SUCCESS
    mpromise.then((data) => {
      console.log(data);
    });
  
     //failure
    mpromise.catch((err) => {
      console.log(err);
    });
  };
  
  readDemo();
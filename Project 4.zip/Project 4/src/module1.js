const fs = require("fs");

 let read = function()
 {

   let path = "C:/Users/hp/Desktop/1.txt";

   const file1 = fs.readFile(path,{encoding : "utf-8"},(err,data) =>
   {
       if(err)
       {
          console.log("its error");
       }
            console.log(data);
   });


        
 };

   read();

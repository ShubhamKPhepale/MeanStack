const fs = require("fs");
const Promise = require("bluebird");


Promise.promisifyAll(fs);

let readDemo = () => 
{
  const filePath1 = "C:/Users/hp/Desktop/1.txt";

  fs.readFileAsync(filePath1, { encoding: "utf-8" }).then((data) => 
  {
      console.log(data);

      const filePath2 = "C:/Users/hp/Desktop/2.txt";
      
      return fs.readFileAsync(filePath2, { encoding: "utf-8" });

    }).then((data) =>
    
     {
      console.log(data);

      const filePath3 = "C:/Users/hp/Desktop/3.txt";
      return fs.readFileAsync(filePath3, { encoding: "utf-8" });

    }).then((data) => 
    
    {
      console.log(data);
    })
    .catch((err) => {
      console.log(err);
    });
};

readDemo();
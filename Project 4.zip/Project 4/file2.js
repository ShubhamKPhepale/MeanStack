
let fs  = require("fs");

/*const promise = require("bluebird");
const { promisify } = require("bluebird");*/

//promise.promisifyAll(fs);  makes all the fs methods sequentially

let read1 = () =>
{

  const path1 = "C:/Users/hp/Desktop/1.txt";

  fs.readFile(path1,{encoding:"utf-8"},(err,data) =>
  {
      console.log("1file",data);

      const path2 = "C:/Users/hp/Desktop/2.txt";

    fs.readFile(path2,{encoding:"utf-8"} ,(err,data) => 
      {

        console.log("file2",data);

        const path3 = "C:/Users/hp/Desktop/3.txt";

         fs.readFile(path3,{encoding:"utf-8"},(err,data) =>
        {

            console.log("file3",data);

        });


      });
});

};

  read1();


 

 
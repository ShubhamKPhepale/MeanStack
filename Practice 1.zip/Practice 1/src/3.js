
  let logic1 = () =>
  {
      console.log("arrow function");
  }

    logic1();
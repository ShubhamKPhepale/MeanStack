
  let logic1 = function()
  {
      console.log("hello anno function");
  }

    logic1();
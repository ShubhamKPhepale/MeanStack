
class Main 
{

      static main()
      {
          console.log("welcome");

          var a = 10;

          var b  = 20;

          var x = a + b;

          console.log(x);

      }

}

  Main.main();

  add1();


  function helloworld()
  {
      console.log("Using functions ");
  }

    helloworld(); //calling function
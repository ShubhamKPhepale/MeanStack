 class Person
 {
     constructor(id,name)
     {
         this.id= id;

         this.name = name;
     }

      info()
      {
          console.log(this.id,this.name);
      }

      static main()
      {
   
    
      var p1 = new Person(1,"samrat");
   
      p1.info();
       
   }
 }

   Person.main();
 
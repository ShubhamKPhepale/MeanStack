
 console.log("hello");

 console.log("hello","welcome to node js world");

 console.log("addition of two number = ",5+3);
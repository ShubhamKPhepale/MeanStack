
 class Info
 {
    setname(id,name)
    {
        this.id = id;

        this.name = name;
    }

    getnameid()
    {
        console.log(this.id,this.name)
    }

      static main()
      {
          let a = new Info();

        a.setname(1,"sandy");
         a.getnameid();
      }


 }

   Info.main();
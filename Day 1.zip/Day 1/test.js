
window.addEventListener("load", function() {
    // We can read BODY Elment Once the page is loaded.
    const pbc = document.querySelector("#parentcontainer");
    console.log(pbc);
  
    for (let i = 0; i < 30; i++) 
    {
      const newElement = pbc.children[0].cloneNode(true);
      newElement.style.display = "flex" ; // none
       newElement.style.color = "blue";
  
      newElement.children[0].innerHTML = "samrat " + i;
  
      pbc.insertBefore(newElement, pbc.firstChild);
    }
  });
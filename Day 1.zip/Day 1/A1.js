
 window.addEventListener("load", () =>
{

      const read = document.querySelector("#node1");

      console.log(read);

     let emp = [ 
     { id: 1, post: "akshay" },
      { id: 2, post: "sandy" },
      { id: 3, post: "rahul" },
      { id: 4, post: "shubham" },

      ];

      for ( let i = 0 ; i < 5; i++)
      {
             let item = emp[i];
     

         const newelement = read.children[0].cloneNode(true);

           newelement.style.display = "flex";

         newelement.children[0].innerHTML = item.post;

        read.insertBefore(newelement,read.firstChild);

    }


});
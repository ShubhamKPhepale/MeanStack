

  function like()
  {
    
      var read = document.querySelector("#inputid1").value;

      const newclone = document.querySelector("#referenceCommentId").cloneNode(true);

      newclone.children[0].innerHTML = read;

      newclone.style.color="red";

      const commentBox = document.querySelector("#commentBox");


      commentBox.insertBefore(newclone, commentBox.firstChild);

       document.querySelector("#inputId1").value = "";

  }

    function delete1()
    {
        var a = document.querySelector("#btnid");

        a.parentElement.remove();
    }

 function click1()
 {

    
     //var read = document.querySelector("#refid");

    
      var para  = document.createElement("div");

      para.innerHTML = "samrat";

      document.querySelector("#refid").appendChild(para);

     
 }
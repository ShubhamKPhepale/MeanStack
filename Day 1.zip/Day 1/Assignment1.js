
  window.addEventListener("load", function() {

     const read = document.querySelector("#parentnode");

     console.log(read);

     for(let i = 0 ; i < 10 ; i++)
     {
     
     const element = read.children[0].cloneNode(true);

     element.style.display = "flex";

     element.style.color = "yellow";

     element.children[0].innerHtml = 'samrat' + i;

     read.insertBefore(element,read.firstChild);

  }

  });